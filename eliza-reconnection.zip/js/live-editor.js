
(function ($) {
  'use strict';

  $(document).ready(function () {
    let isEditMode = true;

        // Comprehensive list of all text elements across all page templates
    const editableSelectors = [
      'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'p', 'li', 'td', 'th', 'dt', 'dd',
      'blockquote', 'cite', 'figcaption',
      '.who', '.kind', '.stat-item strong', '.stat-item span',
      '.stat-item', '.remarks-columns li', '.testi-card p',
      '.lede', '.hero-subtitle', '.tag', '.card-subtitle', '.box-label',
      '.btn', '.eyebrow', '.glass-chip span:not(.pulse-dot)',
      '.portrait-floating-badge', '.bio-photo-badge', '.bio-photo-caption p',
      '.author-bio-tagline', '.single-author-sub', '.tea-cta strong', '.tea-cta p',
      '.glass-box h4', '.glass-box p', '.glass-box li',
      '.video-footer-link', '.video-footer-link a', '.video-footer-link span',
      '.offer-callout', '.offer-highlight-box p', '.offer-highlight-box .box-label'
    ].join(', ');

    // Initialize Edit Mode
    function enableLiveEditing() {
      $('body').addClass('eliza-edit-active');

      // Make all specific text selectors editable
      $('#main').find(editableSelectors).each(function () {
        $(this).attr('contenteditable', 'true');
        $(this).attr('spellcheck', 'false');
      });

      // Ensure any text inside special cards (testimonials, stat items, client remarks) is editable
      $('#main .testi-card, #main .glass-box, #main .stat-list, #main .remarks-columns').find('p, span, strong, em, li, div.who, span.kind').each(function () {
        $(this).attr('contenteditable', 'true');
        $(this).attr('spellcheck', 'false');
      });

      // Wrap content images for click-to-change (exclude emojis, smileys, and icons)
      $('#main img:not(.emoji):not(.wp-smiley):not(.custom-logo):not(.icon-img)').each(function () {
        if (!$(this).parent().hasClass('eliza-editable-img-wrap')) {
          $(this).wrap('<div class="eliza-editable-img-wrap"></div>');
        }
      });
    }

    function disableLiveEditing() {
      $('body').removeClass('eliza-edit-active');
      $('#main').find('[contenteditable="true"]').removeAttr('contenteditable');
      $('#main .eliza-editable-img-wrap').each(function () {
        const $img = $(this).find('img');
        $(this).replaceWith($img);
      });
    }

    // Toggle Edit Mode Button
    $('#eliza-toggle-edit-mode').on('click', function () {
      isEditMode = !isEditMode;
      if (isEditMode) {
        enableLiveEditing();
        $('#eliza-mode-label').text('Editing Active');
        $(this).removeClass('eliza-btn-preview');
        showToast('✏️ Edit Mode Active - Click any text or image');
      } else {
        disableLiveEditing();
        $('#eliza-mode-label').text('Preview Mode');
        $(this).addClass('eliza-btn-preview');
        showToast('👁️ Preview Mode Active');
      }
    });

    // Image Click Handler (WordPress Media Uploader)
    $(document).on('click', '.eliza-editable-img-wrap', function (e) {
      if (!isEditMode) return;
      e.preventDefault();
      const $img = $(this).find('img');

      if (typeof wp !== 'undefined' && wp.media) {
        const customUploader = wp.media({
          title: 'Select or Upload Replacement Image',
          button: { text: 'Use This Photo' },
          multiple: false
        });

        customUploader.on('select', function () {
          const attachment = customUploader.state().get('selection').first().toJSON();
          $img.attr('src', attachment.url);
          showToast('✓ Photo swapped! Click Save Changes.');
        });

        customUploader.open();
      } else {
        const newUrl = prompt('Enter image URL:', $img.attr('src'));
        if (newUrl) {
          $img.attr('src', newUrl);
          showToast('✓ Photo URL updated! Click Save Changes.');
        }
      }
    });

    // Save Changes via AJAX
    $('#eliza-save-live-btn').on('click', function () {
      const $btn = $(this);
      $btn.prop('disabled', true).find('span:last').text('Saving...');

      // Clone #main to clean live-editor temporary wrappers
      const $clone = $('#main').clone();
      $clone.find('[contenteditable]').removeAttr('contenteditable').removeAttr('spellcheck');
      
      // Convert any WP emoji images back into raw text strings
      $clone.find('img.emoji, img.wp-smiley').each(function () {
        const altText = $(this).attr('alt') || '🙂';
        $(this).replaceWith(altText);
      });

      // Unwrap all editable image wrappers
      $clone.find('.eliza-editable-img-wrap').each(function () {
        const $innerImg = $(this).find('img');
        $(this).replaceWith($innerImg);
      });

      const cleanHtml = $clone.html().trim();

      $.ajax({
        url: eliza_live_editor.ajax_url,
        type: 'POST',
        data: {
          action: 'eliza_save_live_page',
          nonce: eliza_live_editor.nonce,
          post_id: eliza_live_editor.post_id,
          content: cleanHtml
        },
        success: function (res) {
          $btn.prop('disabled', false).find('span:last').text('Save Changes');
          if (res.success) {
            showToast('✓ ' + res.data.message);
          } else {
            showToast('❌ Error: ' + (res.data.message || 'Could not save.'));
          }
        },
        error: function () {
          $btn.prop('disabled', false).find('span:last').text('Save Changes');
          showToast('❌ Network error while saving changes.');
        }
      });
    });

    function showToast(msg) {
      const $toast = $('#eliza-live-toast');
      $toast.text(msg).addClass('show');
      setTimeout(function () {
        $toast.removeClass('show');
      }, 3500);
    }

    // Auto-enable upon loading
    enableLiveEditing();
    console.log('Eliza Frontend Live Visual Editor initialized for all cards & boxes!');
  });
})(jQuery);
